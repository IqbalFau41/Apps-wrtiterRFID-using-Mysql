import RPi.GPIO as GPIO
import time
import threading

# Atur mode pin GPIO (BCM mode)
GPIO.setmode(GPIO.BCM)

# Daftar pin untuk tombol dan relay
BUTTON_PINS = [17, 27, 22, 23]  # Sesuaikan dengan pin GPIO yang digunakan untuk tombol
RELAY_PINS = [1, 7, 8, 25]  # Sesuaikan dengan pin GPIO yang digunakan untuk relay

# Inisialisasi pin tombol sebagai input dengan resistor pull-up
for button_pin in BUTTON_PINS:
    GPIO.setup(button_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)

# Inisialisasi pin relay sebagai output dan matikan relay awal
for relay_pin in RELAY_PINS:
    GPIO.setup(relay_pin, GPIO.OUT)
    GPIO.output(relay_pin, GPIO.HIGH)

def activate_relay(button_index):
    print(f"Button {button_index + 1} pressed.")
    GPIO.output(RELAY_PINS[button_index], GPIO.LOW)
    time.sleep(10)  # Relay aktif selama 5 detik
    GPIO.output(RELAY_PINS[button_index], GPIO.HIGH)  # Matikan relay setelah 5 detik

try:
    while True:
        # Periksa status tombol
        for i in range(len(BUTTON_PINS)):
            if GPIO.input(BUTTON_PINS[i]) == GPIO.LOW:
                # Use threading for non-blocking activation of relays
                threading.Thread(target=activate_relay, args=(i,)).start()

except KeyboardInterrupt:
    pass

finally:
    # Matikan relay dan kembalikan pin ke keadaan semula saat program dihentikan
    for relay_pin in RELAY_PINS:
        GPIO.output(relay_pin, GPIO.HIGH)
    GPIO.cleanup()
