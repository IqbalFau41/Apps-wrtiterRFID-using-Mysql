import mysql.connector
import socket
import threading
import time
import RPi.GPIO as GPIO
import datetime

host = '192.168.1.101'
port = 6000

# Define GPIO pins for relays and exit button
relay_1_pin = 1
relay_2_pin = 7
relay_3_pin = 8  # Ganti dengan nomor pin GPIO yang sesuai untuk relay 3
relay_4_pin = 25  # Ganti dengan nomor pin GPIO yang sesuai untuk relay 4

exit_button_pin = 17  # Ganti dengan nomor pin GPIO yang sesuai untuk tombol exit

# Koneksi MySQL
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '123456',
    'database': 'muhamadiyah'
}

waktu_pulang = 15

stop_flag = False
# Timer object to control relay duration
relay_timer = None
# address ID
address_rfid = '04 FF 0F'

# Setup GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(relay_1_pin, GPIO.OUT)
GPIO.setup(relay_2_pin, GPIO.OUT)
GPIO.setup(relay_3_pin, GPIO.OUT)
GPIO.setup(relay_4_pin, GPIO.OUT)
GPIO.setup(exit_button_pin, GPIO.IN, pull_up_down=GPIO.PUD_UP)  # Setup tombol dengan resistor pull-up
GPIO.output(relay_1_pin, GPIO.LOW)  # Initially, turn off relay 1
GPIO.output(relay_2_pin, GPIO.LOW)  # Initially, turn off relay 2
GPIO.setup(relay_3_pin, GPIO.LOW)
GPIO.setup(relay_4_pin, GPIO.LOW)

# Mutex untuk mengunci operasi pada tombol exit
exit_button_lock = threading.Lock()

def get_database_entry(tid):
    try:
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()
        # Query untuk memeriksa kecocokan TID
        query = "SELECT * FROM anggota WHERE rfid = %s"
        cursor.execute(query, (tid,))
        result = cursor.fetchone()
        return result

    except mysql.connector.Error as err:
        print(f"Error: {err}")
        return None

    finally:
        if 'connection' in locals() and connection.is_connected():
            cursor.close()
            connection.close()

# Fungsi untuk menampilkan data dari database
def display_database_entry(entry):
    if entry:
        print(f"Nama     : {entry[1]}")
        print(f"Posisi   : {entry[2]}")
        print(f"RFID     : {entry[3]}")

def crc(cmd):
    cmd = bytes.fromhex(cmd)
    viCrcValue = 0xFFFF
    for x in range(len(cmd)):
        viCrcValue = viCrcValue ^ cmd[x]
        for y in range(8):
            if viCrcValue & 0x0001:
                viCrcValue = (viCrcValue >> 1) ^ 0x8408
            else:
                viCrcValue = viCrcValue >> 1
    crc_H = (viCrcValue >> 8) & 0xFF
    crc_L = viCrcValue & 0xFF
    cmd = cmd + bytes([crc_L])
    cmd = cmd + bytes([crc_H])
    return cmd

def send_cmd(cmd):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    message = crc(cmd)
    s.sendall(message)
    data = s.recv(64)
    response_hex = data.hex().upper()
    hex_list = [response_hex[i:i + 4] for i in range(0, len(response_hex), 4)]
    hex_space = ''.join(hex_list)
    s.close()
    return hex_space

def mark_attendance(entry):
    try:
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()

        # Check if the current time is after 16:00
        current_time = datetime.datetime.now().time()
        closing_time = datetime.time(waktu_pulang, 0, 0)

        if current_time > closing_time:
            # Update 'jam_keluar' for existing entry
            query_update = "UPDATE absensi SET jam_pulang = NOW() WHERE rfid = %s AND tanggal_masuk = DATE(NOW())"
            cursor.execute(query_update, (entry[3],))
            print(f"{entry[1]} berhasil absen pulang pada {time.strftime('%H:%M:%S - %d/%m/%Y')}.")
        else:
            # Check if entry already exists for today
            query_check = "SELECT COUNT(*) FROM absensi WHERE rfid = %s AND tanggal_masuk = DATE(NOW())"
            cursor.execute(query_check, (entry[3],))
            result_check = cursor.fetchone()

            if result_check[0] == 0:
                # Insert into the 'absensi' table if entry does not exist
                query_insert = "INSERT INTO absensi (rfid, nama, tanggal_masuk, jam_masuk) VALUES (%s, %s, NOW(), NOW())"
                cursor.execute(query_insert, (entry[3], entry[1]))
                connection.commit()
                print(f"{entry[1]} berhasil absen pada {time.strftime('%H:%M:%S - %d/%m/%Y')}.")
            else:
                # Get the earliest jam_masuk from existing entries
                query_min_jam_masuk = "SELECT MIN(jam_masuk) FROM absensi WHERE rfid = %s AND tanggal_masuk = DATE(NOW())"
                cursor.execute(query_min_jam_masuk, (entry[3],))
                min_jam_masuk_timedelta = cursor.fetchone()[0]
                # Creating a datetime object with the current date and the timedelta value
                current_date = datetime.datetime.now().date()
                min_jam_masuk_datetime = datetime.datetime.combine(current_date, datetime.datetime.min.time()) + min_jam_masuk_timedelta
                print(f"{entry[1]} sudah absen pada {min_jam_masuk_datetime.strftime('%H:%M:%S')} - {time.strftime('%d/%m/%Y')}.")

        connection.commit()

    except mysql.connector.Error as err:
        print(f"Error: {err}")

    finally:
        if 'connection' in locals() and connection.is_connected():
            cursor.close()
            connection.close()

def exit_button_handler():
    global relay_timer
    while not stop_flag:
        if GPIO.input(exit_button_pin) == GPIO.LOW:
            print("Exit button pressed")
            with exit_button_lock:
                activate_relay(relay_1_pin)
                time.sleep(3)  # Delay untuk menjaga relay 1 aktif selama 10 detik
                deactivate_relay()
        time.sleep(0.1)

def read_and_display():
    global relay_timer
    exit_button_thread = threading.Thread(target=exit_button_handler)
    exit_button_thread.start()

    while not stop_flag:
        result = send_cmd(address_rfid)
        doorlock = result[12:16]
        database_entry = get_database_entry(result)
        if database_entry:
            display_database_entry(database_entry)
            mark_attendance(database_entry)
            print("Doorlock :", doorlock)
            print("_________________________")

            # Activate the corresponding relay(s)
            if doorlock == 'D111' and relay_timer is None:
                activate_relay(relay_1_pin)
                relay_timer = threading.Timer(3, deactivate_relay)
                relay_timer.start()
            elif doorlock == 'D222' and relay_timer is None:
                activate_relay(relay_1_pin)
                activate_relay(relay_2_pin)
                relay_timer = threading.Timer(3, deactivate_relay)
                relay_timer.start()
            elif doorlock == 'D333' and relay_timer is None:
                activate_relay(relay_1_pin)
                activate_relay(relay_2_pin)
                activate_relay(relay_3_pin)
                relay_timer = threading.Timer(3, deactivate_relay)
                relay_timer.start()
            elif doorlock == 'D444' and relay_timer is None:
                activate_relay(relay_1_pin)
                activate_relay(relay_2_pin)
                activate_relay(relay_3_pin)
                activate_relay(relay_4_pin)
                relay_timer = threading.Timer(3, deactivate_relay)
                relay_timer.start()

        else:
            print("Member not found in database.")

    exit_button_thread.join()

def activate_relay(relay_pin):
    GPIO.output(relay_pin, GPIO.HIGH)
    print(f"Relay {relay_pin} activated")

def deactivate_relay():
    GPIO.output(relay_1_pin, GPIO.LOW)
    GPIO.output(relay_2_pin, GPIO.LOW)
    GPIO.output(relay_3_pin, GPIO.LOW)
    GPIO.output(relay_4_pin, GPIO.LOW)
    print("Relays deactivated")
    time.sleep(2)  # Delay setelah relay dimatikan
    global relay_timer
    relay_timer = None

if __name__ == "__main__":
    try:
        read_and_display()
    except KeyboardInterrupt:
        stop_flag = True
        GPIO.cleanup()
