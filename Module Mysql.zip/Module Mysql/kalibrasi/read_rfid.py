import socket

host = '192.168.1.101'
port = 6000

# membaca TID
inventory = '96 03 01 00 06' 
# membaca EPC
rfid = '04 FF 0F'
# read EPC
readTagMem = '12 03 02 02 11 22 33 44 01 00 04 00 00 00 00 00 03'
# change EPC
writeEpc = '0F 09 04 03 00 00 00 00 D1 11 00 00 00 01'
# set adrres a 00 menjadi 09
setAddress = '05 00 24 09' 
# kalibrasi
set = rfid

def crc(cmd):
    cmd = bytes.fromhex(cmd)
    viCrcValue = 0xFFFF
    for x in range ((len(cmd))):
        viCrcValue = viCrcValue ^ cmd[x]
        for y in range(8):
            if (viCrcValue & 0x0001):
                viCrcValue = (viCrcValue >> 1) ^ 0x8408
            else:
                viCrcValue = viCrcValue >> 1
    crc_H = (viCrcValue >> 8) & 0xFF
    crc_L = viCrcValue & 0xFF
    cmd = cmd + bytes([crc_L])
    cmd = cmd + bytes([crc_H])
    return cmd

# ini jangan dihapus
#def send_cmd(cmd):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    message = crc(cmd)
    s.sendall(message)
    data = s.recv(64)
    response_hex = data.hex().upper()
    hex_no_space = response_hex.replace(" ", "")  # Menghapus spasi dari hex
    print(hex_no_space)
    s.close()

def send_cmd(cmd):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    message = crc(cmd)
    s.sendall(message)
    data = s.recv(64)
    response_hex = data.hex().upper()
    hex_list = [response_hex[i:i + 2] for i in range(0, len(response_hex), 2)]  # Memisahkan tiap 4 karakter
    hex_space = ' '.join(hex_list)
    print(hex_space)
    s.close()

send_cmd(set)