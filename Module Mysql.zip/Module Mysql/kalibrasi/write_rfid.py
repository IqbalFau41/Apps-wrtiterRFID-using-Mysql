import socket

host = '192.168.1.101'
port = 6000

# membaca EPC
rfid = '04 FF 0F'
# change EPC
writeEpc_prefix = '0F 99 04 03 00 00 00 00'
writeEpc_level = 'D1 12'
writeEpc_nomor = '34 56 78 98'

# kalibrasi
set = writeEpc_prefix + writeEpc_level + writeEpc_nomor

def crc(cmd):
    cmd = bytes.fromhex(cmd)
    viCrcValue = 0xFFFF
    for x in range ((len(cmd))):
        viCrcValue = viCrcValue ^ cmd[x]
        for y in range(8):
            if (viCrcValue & 0x0001):
                viCrcValue = (viCrcValue >> 1) ^ 0x8408
            else:
                viCrcValue = viCrcValue >> 1
    crc_H = (viCrcValue >> 8) & 0xFF
    crc_L = viCrcValue & 0xFF
    cmd = cmd + bytes([crc_L])
    cmd = cmd + bytes([crc_H])
    return cmd

def send_cmd(cmd):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    message = crc(cmd)
    s.sendall(message)
    data = s.recv(64)
    response_hex = data.hex().upper()
    hex_list = [response_hex[i:i + 4] for i in range(0, len(response_hex), 4)]  # Memisahkan tiap 4 karakter
    hex_space = ' '.join(hex_list)
    print(hex_space)
    s.close()

# Menerima input dari pengguna untuk bagian yang diubah
user_input = input("Masukkan nilai untuk bagian yang diubah (contoh: D1 12): ").strip()

# Memperbarui bagian yang diubah dengan input pengguna
writeEpc_level = user_input

# Menggabungkan prefix dan suffix untuk membentuk set baru
set = writeEpc_prefix + writeEpc_level + writeEpc_nomor

# Mengirimkan perintah dengan set yang telah diperbarui
send_cmd(set)
