import mysql.connector
import socket
import random

# Fungsi untuk koneksi ke database
def connect_database():
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",  # Ganti dengan username Anda
            password="123456",  # Ganti dengan password Anda
            database="muhamadiyah"  # Ganti dengan nama database Anda
        )
        return connection
    except mysql.connector.Error as err:
        print("Error: ", err)

# membaca EPC
rfid = '04 FF 0F'
# change EPC
writeEpc_prefix = '0F 99 04 03 00 00 00 00'
# Menggunakan angka random untuk writeEpc_nomor
writeEpc_nomor = ' '.join([format(random.randint(0, 255), '02X') for _ in range(4)])

def crc(cmd):
    cmd = bytes.fromhex(cmd)
    viCrcValue = 0xFFFF
    for x in range((len(cmd))):
        viCrcValue = viCrcValue ^ cmd[x]
        for y in range(8):
            if (viCrcValue & 0x0001):
                viCrcValue = (viCrcValue >> 1) ^ 0x8408
            else:
                viCrcValue = viCrcValue >> 1
    crc_H = (viCrcValue >> 8) & 0xFF
    crc_L = viCrcValue & 0xFF
    cmd = cmd + bytes([crc_L])
    cmd = cmd + bytes([crc_H])
    return cmd

def read_rfid():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(('192.168.1.101', 6000))
    message = crc(rfid)
    s.sendall(message)
    data = s.recv(64)
    response_hex = data.hex().upper()
    hex_list = [response_hex[i:i + 4] for i in range(0, len(response_hex), 4)]
    hex_space = ''.join(hex_list)
    s.close()
    return hex_space

def send_cmd(cmd):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(('192.168.1.101', 6000))
    message = crc(cmd)
    s.sendall(message)
    data = s.recv(64)
    response_hex = data.hex().upper()
    hex_list = [response_hex[i:i + 4] for i in range(0, len(response_hex), 4)]
    hex_space = ''.join(hex_list)
    print(hex_space)
    s.close()

# Baca nomor rfid sebelum inputan
print("Nomor RFID sebelum inputan:", read_rfid())

# Baca identitas terlebih dahulu
nama_lengkap = input("Masukkan nama lengkap: ").strip()
posisi = input("Masukkan posisi: ").strip()

# Menerima input dari pengguna untuk level
level_input = input("Masukkan level (1-5): ").strip()

if level_input in ['1', '2', '3', '4', '5']:
    writeEpc_level = f'D{level_input} {int(level_input) * 11:02d}'
else:
    print("Level tidak valid. Hanya level 1-5 yang diperbolehkan.")
    exit()

set = writeEpc_prefix + writeEpc_level + writeEpc_nomor

# Send cmd untuk melakukan inputan
send_cmd(set)

# Baca nomor rfid sesudah inputan
nomor_rfid_sesudah_inputan = read_rfid()
print("Nomor RFID sesudah inputan:", nomor_rfid_sesudah_inputan)

# Menghubungkan ke database
connection = connect_database()

if connection:
    try:
        cursor = connection.cursor()
        
        # Menjalankan query untuk menyimpan data ke dalam tabel
        sql = "INSERT INTO anggota (nama, posisi, level, rfid) VALUES (%s, %s, %s, %s)"
        val = (nama_lengkap, posisi, level_input, nomor_rfid_sesudah_inputan)

        cursor.execute(sql, val)

        # Melakukan commit perubahan
        connection.commit()

        print("Data berhasil disimpan ke database.")
    except mysql.connector.Error as err:
        print("Error: ", err)
    finally:
        cursor.close()
        connection.close()
else:
    print("Gagal terhubung ke database.")
