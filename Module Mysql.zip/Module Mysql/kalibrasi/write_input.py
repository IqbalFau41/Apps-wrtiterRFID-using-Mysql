import socket
import random

host = '192.168.1.101'
port = 6000

# membaca EPC
rfid = '04 FF 0F'
# change EPC
writeEpc_prefix = '0F 99 04 03 00 00 00 00'
# Menggunakan angka random untuk writeEpc_nomor
writeEpc_nomor = ' '.join([format(random.randint(0, 255), '02X') for _ in range(4)])

def crc(cmd):
    cmd = bytes.fromhex(cmd)
    viCrcValue = 0xFFFF
    for x in range((len(cmd))):
        viCrcValue = viCrcValue ^ cmd[x]
        for y in range(8):
            if (viCrcValue & 0x0001):
                viCrcValue = (viCrcValue >> 1) ^ 0x8408
            else:
                viCrcValue = viCrcValue >> 1
    crc_H = (viCrcValue >> 8) & 0xFF
    crc_L = viCrcValue & 0xFF
    cmd = cmd + bytes([crc_L])
    cmd = cmd + bytes([crc_H])
    return cmd

def read_rfid():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    message = crc(rfid)
    s.sendall(message)
    data = s.recv(64)
    response_hex = data.hex().upper()
    hex_list = [response_hex[i:i + 4] for i in range(0, len(response_hex), 4)]
    hex_space = ' '.join(hex_list)
    s.close()
    return hex_space

def send_cmd(cmd):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    message = crc(cmd)
    s.sendall(message)
    data = s.recv(64)
    response_hex = data.hex().upper()
    hex_list = [response_hex[i:i + 4] for i in range(0, len(response_hex), 4)]
    hex_space = ' '.join(hex_list)
    print(hex_space)
    s.close()

# Baca nomor rfid sebelum inputan
print("Nomor RFID sebelum inputan:", read_rfid())

# Baca identitas terlebih dahulu
nama_lengkap = input("Masukkan nama lengkap: ").strip()
posisi = input("Masukkan posisi: ").strip()

# Menerima input dari pengguna untuk level
level_input = input("Masukkan level (1-5): ").strip()

if level_input in ['1', '2', '3', '4', '5']:
    writeEpc_level = f'D{level_input} {int(level_input) * 11:02d}'
else:
    print("Level tidak valid. Hanya level 1-5 yang diperbolehkan.")
    exit()

set = writeEpc_prefix + writeEpc_level + writeEpc_nomor

# Send cmd untuk melakukan inputan
send_cmd(set)

# Baca nomor rfid sesudah inputan
print("Nomor RFID sesudah inputan:", read_rfid())