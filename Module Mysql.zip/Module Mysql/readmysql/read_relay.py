import mysql.connector
import socket
import RPi.GPIO as GPIO

# Koneksi MySQL
conn = mysql.connector.connect(
    host='localhost',
    user='root',
    database='muhamadiyah',
    password='123456',
)

mycursor = conn.cursor()

# Fungsi untuk membaca data dari database berdasarkan TID
def get_database_entry(tid):
    query = "SELECT * FROM anggota WHERE rfid = %s"
    mycursor.execute(query, (tid,))
    result = mycursor.fetchone()
    return result

# Fungsi untuk menampilkan data dari database
def display_database_entry(entry):
    if entry:
        print(f"Nama: {entry[1]}")
        print(f"Posisi: {entry[2]}")
        print(f"TID: {entry[3]}")

        # Menambahkan informasi Doorlock dari data ke-10 hingga ke-14
        doorlock_info = ''.join(entry[3][15:19]).replace(" ", "")
        print(f"Doorlock: {doorlock_info}")
        return doorlock_info
    else:
        print("RFID tidak ditemukan di database")
        return None

# Fungsi untuk mengirim perintah ke perangkat RFID
def send_cmd(cmd):
    host = '192.168.1.101'
    port = 6000

    # EPC
    PRESENT_Value = 0xFFFF
    POLYNOMIAL = 0x8408

    def crc(cmd):
        cmd = bytes.fromhex(cmd)
        viCrcValue = PRESENT_Value
        for x in range(len(cmd)):
            viCrcValue = viCrcValue ^ cmd[x]
            for y in range(8):
                if (viCrcValue & 0x0001):
                    viCrcValue = (viCrcValue >> 1) ^ POLYNOMIAL
                else:
                    viCrcValue = viCrcValue >> 1
        crc_H = (viCrcValue >> 8) & 0xFF
        crc_L = viCrcValue & 0xFF
        cmd = cmd + bytes([crc_L])
        cmd = cmd + bytes([crc_H])
        return cmd

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    message = crc(cmd)
    s.sendall(message)
    data = s.recv(64)
    response_hex = data.hex().upper()
    hex_list = [response_hex[i:i + 4] for i in range(0, len(response_hex), 4)]
    hex_space = ' '.join(hex_list)
    s.close()
    return hex_space, hex_list  # Return both formatted and raw hex

# Inisialisasi GPIO untuk relay
relay_1_pin = 18
relay_2_pin = 23
GPIO.setmode(GPIO.BCM)
GPIO.setup(relay_1_pin, GPIO.OUT)
GPIO.setup(relay_2_pin, GPIO.OUT)
GPIO.output(relay_1_pin, GPIO.LOW)  # Initially, turn off relay 1
GPIO.output(relay_2_pin, GPIO.LOW)  # Initially, turn off relay 2

try:
    while True:
        # Membaca TID dari perangkat RFID
        tid_result, hex_list = send_cmd('04 FF 0F')
        print("TID RFID:", tid_result)

        # Menampilkan data dari database
        database_entry = get_database_entry(tid_result)
        doorlock_info = display_database_entry(database_entry)

        # Kontrol relay berdasarkan nilai Doorlock
        if doorlock_info == 'D111':
            GPIO.output(relay_1_pin, GPIO.HIGH)
        elif doorlock_info == 'D222':
            GPIO.output(relay_1_pin, GPIO.HIGH)
            GPIO.output(relay_2_pin, GPIO.HIGH)
        else:
            GPIO.output(relay_1_pin, GPIO.LOW)
            GPIO.output(relay_2_pin, GPIO.LOW)

except KeyboardInterrupt:
    print("Program dihentikan.")
finally:
    conn.close()
    GPIO.cleanup()
