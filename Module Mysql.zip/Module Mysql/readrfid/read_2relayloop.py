import mysql.connector
import socket
import threading
import time
import RPi.GPIO as GPIO

host = '192.168.1.101'
port = 6000

# Define GPIO pins for relays
relay_1_pin = 18
relay_2_pin = 23

# Koneksi MySQL
conn = mysql.connector.connect(
    host='localhost',
    user='root',
    database='muhamadiyah',
    password='123456',
)

mycursor = conn.cursor()

stop_flag = False
# Timer object to control relay duration
relay_timer = None  
# address ID
address_rfid = '04 FF 0F'

# Setup GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(relay_1_pin, GPIO.OUT)
GPIO.setup(relay_2_pin, GPIO.OUT)
GPIO.output(relay_1_pin, GPIO.LOW)  # Initially, turn off relay 1
GPIO.output(relay_2_pin, GPIO.LOW)  # Initially, turn off relay 2

# Fungsi untuk membaca data dari database berdasarkan TID
def get_database_entry(tid):
    query = "SELECT * FROM anggota WHERE rfid = %s"
    mycursor.execute(query, (tid,))
    result = mycursor.fetchone()
    return result

# Fungsi untuk menampilkan data dari database
def display_database_entry(entry):
    if entry:
        print(f"Nama     : {entry[1]}")
        print(f"Posisi   : {entry[2]}")
        print(f"RFID     : {entry[3]}")

def crc(cmd):
    cmd = bytes.fromhex(cmd)
    viCrcValue = 0xFFFF
    for x in range(len(cmd)):
        viCrcValue = viCrcValue ^ cmd[x]
        for y in range(8):
            if viCrcValue & 0x0001:
                viCrcValue = (viCrcValue >> 1) ^ 0x8408
            else:
                viCrcValue = viCrcValue >> 1
    crc_H = (viCrcValue >> 8) & 0xFF
    crc_L = viCrcValue & 0xFF
    cmd = cmd + bytes([crc_L])
    cmd = cmd + bytes([crc_H])
    return cmd

def send_cmd(cmd):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    message = crc(cmd)
    s.sendall(message)
    data = s.recv(64)
    response_hex = data.hex().upper()
    hex_list = [response_hex[i:i + 2] for i in range(0, len(response_hex), 2)]
    hex_space = ''.join(hex_list[6:18])
    s.close()
    return hex_space

def read_and_display():
    global relay_timer
    while not stop_flag:
        result = send_cmd(address_rfid)
        doorlock = result[11:15]
        database_entry = get_database_entry(result)
        if database_entry:
            display_database_entry(database_entry)
            print("Doorlock :", doorlock)
            print("_________________________")
            # Activate the corresponding relay(s)
            if doorlock == 'D111' and relay_timer is None:
                activate_relay(relay_1_pin)
                relay_timer = threading.Timer(5, deactivate_relay)
                relay_timer.start()
            elif doorlock == 'D222' and relay_timer is None:
                activate_relay(relay_1_pin)
                activate_relay(relay_2_pin)
                relay_timer = threading.Timer(5, deactivate_relay)
                relay_timer.start()
        else:
            print("Member not found in database.")

def activate_relay(relay_pin):
    GPIO.output(relay_pin, GPIO.HIGH)
    print(f"Relay {relay_pin} activated")

def deactivate_relay():
    GPIO.output(relay_1_pin, GPIO.LOW)
    GPIO.output(relay_2_pin, GPIO.LOW)
    print("Relays deactivated")
    global relay_timer
    relay_timer = None

if __name__ == "__main__":
    try:
        read_and_display()
    except KeyboardInterrupt:
        stop_flag = True
        GPIO.cleanup()
        conn.close()
