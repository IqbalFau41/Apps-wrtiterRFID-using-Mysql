import socket
import threading
import time
import RPi.GPIO as GPIO

host = '192.168.1.101'
port = 6000

# address ID
address_rfid = '04 FF 0F'

# EPC
PRESENT_Value = 0xFFFF
POLYNOMIAL = 0x8408

stop_flag = False

# Define GPIO pins for relays
relay_pin = 18

# Setup GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(relay_pin, GPIO.OUT)
GPIO.output(relay_pin, GPIO.LOW)  # Initially, turn off the relay

relay_timer = None  # Timer object to control relay duration

def crc(cmd):
    cmd = bytes.fromhex(cmd)
    viCrcValue = PRESENT_Value
    for x in range(len(cmd)):
        viCrcValue = viCrcValue ^ cmd[x]
        for y in range(8):
            if viCrcValue & 0x0001:
                viCrcValue = (viCrcValue >> 1) ^ POLYNOMIAL
            else:
                viCrcValue = viCrcValue >> 1
    crc_H = (viCrcValue >> 8) & 0xFF
    crc_L = viCrcValue & 0xFF
    cmd = cmd + bytes([crc_L])
    cmd = cmd + bytes([crc_H])
    return cmd

def send_cmd(cmd):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((host, port))
    message = crc(cmd)
    s.sendall(message)
    data = s.recv(64)
    response_hex = data.hex().upper()
    hex_list = [response_hex[i:i + 2] for i in range(0, len(response_hex), 2)]
    hex_space = ''.join(hex_list[6:18])
    s.close()
    return hex_space

def read_and_display():
    global relay_timer

    while not stop_flag:
        result = send_cmd(address_rfid)
        dd11_value = result[11:15]
        print(dd11_value)

        # Check if the RFID code is D111, then activate the relay
        if dd11_value == 'D111' and relay_timer is None:
            activate_relay()
            relay_timer = threading.Timer(5, deactivate_relay)
            relay_timer.start()

def activate_relay():
    GPIO.output(relay_pin, GPIO.HIGH)
    print("Relay activated")

def deactivate_relay():
    GPIO.output(relay_pin, GPIO.LOW)
    print("Relay deactivated")
    global relay_timer
    relay_timer = None

if __name__ == "__main__":
    try:
        read_and_display()
    except KeyboardInterrupt:
        stop_flag = True
        GPIO.cleanup()
